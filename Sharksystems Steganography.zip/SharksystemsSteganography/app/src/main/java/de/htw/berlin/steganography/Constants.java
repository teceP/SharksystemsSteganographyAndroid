package de.htw.berlin.steganography;

public interface Constants {
    String AUTH_URI = "https://www.reddit.com/api/v1/authorize";
    String TOKEN_URI = "https://www.reddit.com/api/v1/access_token";
}
